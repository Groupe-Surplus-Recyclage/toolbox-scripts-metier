function Afficher-Interfaces {
    Write-Host "`nRecherche des interfaces en cours..." -ForegroundColor Gray
    $adapters = Get-NetAdapter | Sort-Object Status -Descending
    $global:listeCartes = @()
    $i = 1
    
    Write-Host "`n--- Liste des Cartes Reseau (Actives en haut) ---" -ForegroundColor Cyan
    Write-Host ("{0,-4} {1,-30} {2,-15} {3,-18} {4,-5} {5}" -f "ID", "InterfaceAlias", "Status", "IPAddress", "Index", "Description") -ForegroundColor White

    foreach ($adapter in $adapters) {
        $ipInfo = Get-NetIPAddress -InterfaceIndex $adapter.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1
        $ip = if ($ipInfo) { $ipInfo.IPAddress } else { "---" }
        
        $obj = [PSCustomObject]@{ 'ID' = $i; 'Alias' = $adapter.Name; 'Index' = $adapter.InterfaceIndex }
        $global:listeCartes += $obj

        $statusColor = if ($adapter.Status -eq "Up") { "Green" } else { "Red" }
        Write-Host ("{0,-4} {1,-30} " -f $i, $adapter.Name) -NoNewline
        Write-Host ("{0,-15} " -f $adapter.Status) -ForegroundColor $statusColor -NoNewline
        Write-Host ("{0,-18} {1,-5} {2}" -f $ip, $adapter.InterfaceIndex, $adapter.InterfaceDescription)
        $i++
    }
}

function Convertir-PrefixeEnMasque($prefix) {
    $prefix = [int]$prefix
    $binaryMask = ("1" * $prefix).PadRight(32, "0")
    $octets = @()
    for ($i = 0; $i -lt 32; $i += 8) {
        $octets += [Convert]::ToInt32($binaryMask.Substring($i, 8), 2)
    }
    return $octets -join "."
}

function Configurer-IPFixe {
    Afficher-Interfaces
    $choixID = Read-Host "`nSelectionnez le numero ID"
    $carte = $global:listeCartes | Where-Object { $_.ID -eq $choixID }
    if (-not $carte) { return }

    $ip = Read-Host "Entrez l'adresse IP"
    $maskInput = Read-Host "Entrez le masque (ex: 255.255.255.0 ou 24)"
    $gateway = Read-Host "Entrez la passerelle"
    $dnsInput = Read-Host "Entrez le DNS (laisser vide = utiliser la passerelle)"
    $dns = if ($dnsInput -eq "") { $gateway } else { $dnsInput }

    if ($maskInput.Length -le 2) {
        $maskFull = Convertir-PrefixeEnMasque $maskInput
    } else {
        $maskFull = $maskInput
    }

    try {
        Write-Host "Nettoyage complet de l'interface $($carte.Alias)..." -ForegroundColor Gray

        Remove-NetIPAddress -InterfaceIndex $carte.Index -AddressFamily IPv4 -Confirm:$false -ErrorAction SilentlyContinue
        Remove-NetRoute -InterfaceIndex $carte.Index -Confirm:$false -ErrorAction SilentlyContinue

        $result = netsh interface ip set address name="$($carte.Alias)" static $ip $maskFull $gateway

        if ($LASTEXITCODE -eq 0) {
            netsh interface ip set dns name="$($carte.Alias)" static $dns | Out-Null
            Write-Host "Succes ! IP=$ip | Masque=$maskFull | GW=$gateway | DNS=$dns" -ForegroundColor Green
        } else {
            Write-Host "Erreur netsh : $result" -ForegroundColor Red
        }

    } catch {
        Write-Host "Erreur : $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Configurer-DHCP {
    Afficher-Interfaces
    $choixID = Read-Host "`nSelectionnez le numero ID"
    $carte = $global:listeCartes | Where-Object { $_.ID -eq $choixID }
    if ($carte) {
        try {
            Set-NetIPInterface -InterfaceIndex $carte.Index -Dhcp Enabled
            Set-DnsClientServerAddress -InterfaceIndex $carte.Index -ResetServerAddresses
            Write-Host "DHCP Reactive." -ForegroundColor Green
        } catch {
            Write-Host "Erreur lors du passage en DHCP." -ForegroundColor Red
        }
    }
}

function Reset-Reseau {
    Afficher-Interfaces
    $choixID = Read-Host "`nSelectionnez le numero ID"
    $carte = $global:listeCartes | Where-Object { $_.ID -eq $choixID }
    if (-not $carte) { return }

    Write-Host "Execution : FlushDNS, Release, Renew sur $($carte.Alias)..." -ForegroundColor Yellow
    ipconfig /flushdns
    ipconfig /release "$($carte.Alias)"
    ipconfig /renew "$($carte.Alias)"
    Write-Host "Maintenance terminee !" -ForegroundColor Green
}

function Afficher-ConfigCarte {
    Afficher-Interfaces
    $choixID = Read-Host "`nSelectionnez le numero ID"
    $carte = $global:listeCartes | Where-Object { $_.ID -eq $choixID }
    if (-not $carte) { return }

    $adapter = Get-NetAdapter -InterfaceIndex $carte.Index
    $ipInfo = Get-NetIPAddress -InterfaceIndex $carte.Index -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1
    $gwInfo = Get-NetRoute -InterfaceIndex $carte.Index -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Select-Object -First 1
    $dnsInfo = Get-DnsClientServerAddress -InterfaceIndex $carte.Index -AddressFamily IPv4 -ErrorAction SilentlyContinue
    $dhcpInfo = Get-NetIPInterface -InterfaceIndex $carte.Index -AddressFamily IPv4 -ErrorAction SilentlyContinue

    Write-Host "`n--- Configuration de $($carte.Alias) ---" -ForegroundColor Cyan
    Write-Host ("Description  : {0}" -f $adapter.InterfaceDescription)
    Write-Host ("MAC          : {0}" -f $adapter.MacAddress)
    Write-Host ("Statut       : {0}" -f $adapter.Status)
    Write-Host ("Mode         : {0}" -f $(if ($dhcpInfo.Dhcp -eq "Enabled") { "DHCP" } else { "IP Fixe" }))
    Write-Host ("IP           : {0}" -f $(if ($ipInfo) { $ipInfo.IPAddress } else { "---" }))
    Write-Host ("Masque (/xx) : {0}" -f $(if ($ipInfo) { $ipInfo.PrefixLength } else { "---" }))
    Write-Host ("Passerelle   : {0}" -f $(if ($gwInfo) { $gwInfo.NextHop } else { "---" }))
    Write-Host ("DNS          : {0}" -f $(if ($dnsInfo.ServerAddresses) { $dnsInfo.ServerAddresses -join ", " } else { "---" }))
}

function Ping-Test {
    Afficher-Interfaces
    $choixID = Read-Host "`nSelectionnez le numero ID source"
    $carte = $global:listeCartes | Where-Object { $_.ID -eq $choixID }
    if (-not $carte) { return }

    $cible = Read-Host "Entrez l'IP ou hote a pinger (laisser vide = passerelle)"
    
    if ($cible -eq "") {
        $gwInfo = Get-NetRoute -InterfaceIndex $carte.Index -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Select-Object -First 1
        $cible = if ($gwInfo) { $gwInfo.NextHop } else { $null }
        if (-not $cible) { Write-Host "Aucune passerelle trouvee." -ForegroundColor Red; return }
    }

    Write-Host "`nPing vers $cible depuis $($carte.Alias)..." -ForegroundColor Yellow
    $results = Test-Connection -ComputerName $cible -Count 4 -ErrorAction SilentlyContinue

    if ($results) {
        foreach ($r in $results) {
            Write-Host ("Reponse de {0} : {1}ms" -f $r.Address, $r.ResponseTime) -ForegroundColor Green
        }
        $avg = ($results | Measure-Object -Property ResponseTime -Average).Average
        Write-Host ("Moyenne : {0:N1}ms" -f $avg) -ForegroundColor Cyan
    } else {
        Write-Host "Aucune reponse de $cible" -ForegroundColor Red
    }
}

function Changer-DNS {
    Afficher-Interfaces
    $choixID = Read-Host "`nSelectionnez le numero ID"
    $carte = $global:listeCartes | Where-Object { $_.ID -eq $choixID }
    if (-not $carte) { return }

    Write-Host "`nExemples : 8.8.8.8 (Google) | 1.1.1.1 (Cloudflare) | 9.9.9.9 (Quad9)" -ForegroundColor Gray
    $dns1 = Read-Host "DNS primaire"
    $dns2 = Read-Host "DNS secondaire (laisser vide = aucun)"

    try {
        if ($dns2 -eq "") {
            Set-DnsClientServerAddress -InterfaceIndex $carte.Index -ServerAddresses $dns1
        } else {
            Set-DnsClientServerAddress -InterfaceIndex $carte.Index -ServerAddresses $dns1, $dns2
        }
        Write-Host "DNS mis a jour avec succes." -ForegroundColor Green
    } catch {
        Write-Host "Erreur : $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Afficher-TableRoutage {
    Write-Host "`n--- Table de routage IPv4 ---" -ForegroundColor Cyan
    Get-NetRoute -AddressFamily IPv4 | Sort-Object RouteMetric |
        Format-Table -AutoSize DestinationPrefix, NextHop, RouteMetric, InterfaceAlias, InterfaceIndex
}

function Test-Connectivite {
    Afficher-Interfaces
    $choixID = Read-Host "`nSelectionnez le numero ID"
    $carte = $global:listeCartes | Where-Object { $_.ID -eq $choixID }
    if (-not $carte) { return }

    Write-Host "`n--- Test de connectivite sur $($carte.Alias) ---" -ForegroundColor Cyan

    # Test passerelle
    $gwInfo = Get-NetRoute -InterfaceIndex $carte.Index -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($gwInfo) {
        $pingGW = Test-Connection -ComputerName $gwInfo.NextHop -Count 2 -ErrorAction SilentlyContinue
        if ($pingGW) {
            Write-Host ("[OK] Passerelle {0} repond ({1}ms)" -f $gwInfo.NextHop, ($pingGW | Measure-Object ResponseTime -Average).Average) -ForegroundColor Green
        } else {
            Write-Host ("[KO] Passerelle {0} ne repond pas" -f $gwInfo.NextHop) -ForegroundColor Red
        }
    } else {
        Write-Host "[KO] Aucune passerelle configuree" -ForegroundColor Red
    }

    # Test IP externe
    $pingExt = Test-Connection -ComputerName "8.8.8.8" -Count 2 -ErrorAction SilentlyContinue
    if ($pingExt) {
        Write-Host ("[OK] Internet (8.8.8.8) repond ({0}ms)" -f ($pingExt | Measure-Object ResponseTime -Average).Average) -ForegroundColor Green
    } else {
        Write-Host "[KO] Internet (8.8.8.8) ne repond pas" -ForegroundColor Red
    }

    # Test DNS
    $pingDNS = Test-Connection -ComputerName "google.com" -Count 2 -ErrorAction SilentlyContinue
    if ($pingDNS) {
        Write-Host ("[OK] DNS OK - google.com repond ({0}ms)" -f ($pingDNS | Measure-Object ResponseTime -Average).Average) -ForegroundColor Green
    } else {
        Write-Host "[KO] DNS KO - google.com ne repond pas (verifier DNS)" -ForegroundColor Red
    }
}

function Traceroute {
    $cible = Read-Host "`nEntrez la destination (IP ou nom d'hote)"
    Write-Host "`nTraceroute vers $cible..." -ForegroundColor Yellow
    tracert $cible
}

# --- Menu ---
do {
    Write-Host "`n================ MENU GESTION RESEAU V10 ================" -ForegroundColor Blue
    Write-Host "1.  Lister les cartes"
    Write-Host "2.  Passer en IP Fixe"
    Write-Host "3.  Remettre en DHCP"
    Write-Host "4.  Flush / Release / Renew"
    Write-Host "5.  Afficher config complete d'une carte"
    Write-Host "6.  Ping de test"
    Write-Host "7.  Changer le DNS"
    Write-Host "8.  Afficher la table de routage"
    Write-Host "9.  Test de connectivite (GW + Internet + DNS)"
    Write-Host "10. Traceroute"
    Write-Host "Q.  Quitter"
    $choix = Read-Host "Votre choix "
    switch ($choix) {
        "1"  { Afficher-Interfaces }
        "2"  { Configurer-IPFixe }
        "3"  { Configurer-DHCP }
        "4"  { Reset-Reseau }
        "5"  { Afficher-ConfigCarte }
        "6"  { Ping-Test }
        "7"  { Changer-DNS }
        "8"  { Afficher-TableRoutage }
        "9"  { Test-Connectivite }
        "10" { Traceroute }
    }
} while ($choix -ne "Q")