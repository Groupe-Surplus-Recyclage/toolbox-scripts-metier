@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell '-NoProfile -ExecutionPolicy Bypass -File GestionReseau.ps1' -Verb RunAs"